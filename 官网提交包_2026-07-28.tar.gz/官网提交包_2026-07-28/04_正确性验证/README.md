# 04 · 正确性验证

- `scripts/` — accuracy / irregular / backward / 3D / FNO forward
- `results.md` — 结果汇总
- `results/` — accuracy 相关 run_logs + `summary.json`

验收标准：SpectralConv 相对误差 ≤ 1e-4（本包 worst ≈ 2.83e-7）。