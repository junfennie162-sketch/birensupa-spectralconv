# 06 · 运行日志或截图

- `run_logs/` — 各次运行记录（≥8 个 md/json）
- `logs/` — 编译/运行原始日志
- `phase_status.json` — 6 phase 状态（全部 done）

对应官方「运行日志或截图」条目。