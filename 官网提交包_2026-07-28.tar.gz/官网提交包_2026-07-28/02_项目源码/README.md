# 02 · 项目源码

## `spectral_conv_combo/`（必选算子 · 主提交）
- `spectral_conv_ext.cpp` / `.su` / `.so` — SUPA Extension
- `spectral_conv_ops.py` — v1 + fused + auto-tune + dual_out
- `build.sh`、测试脚本、`tune.py`

## `fno_ns/`（进阶 C · FNO-NS）
- `model.py` — ≥4 层 Fourier Layer，复用 SpectralConv
- `dataset.py`、`train_official.py`、`test_forward.py`、`visualize.py`
- `checkpoints/fno_ns_demo.pt` — 预训练权重（单次推理可用）

说明：大数据 cache（`ns_like_*.pt`）未打入本包，首次训练会自动生成。