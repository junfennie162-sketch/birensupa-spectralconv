# 01 · skill.md（必须）

官方要求：**必须提交 skill.md**。

本目录文件：
- `SKILL.md` — 大写（平台要求兼容）
- `skill.md` — 小写副本（同内容）
- `SKILLS_SUMMARY_2026-07-25.md` — 全部 Skill 汇总
- `skills/` — 子 Skill（spectral_conv_dev / fno_experiment）

表单填写：
- 名称：`fno-spectral-conv-supa`
- 描述：见 `SKILL.md` 内「Skill 描述」代码块（≤500 字符）