# 05 · 性能测试与报告

- `scripts/test_perf.py` — 延迟 + 显存
- `scripts/test_perf_grid_points.py` — 官方口径 grid_points/s（bs=16）
- `scripts/tune.py` — Auto-Tuning
- `results/` — perf 日志 + `spectral_grid_points.json`
- `results.md` — 性能表

参考：64/128/256 → 5.32 / 13.69 / 52.64 ms；bs=16 → 0.88M / 3.30M / 4.93M grid_points/s。