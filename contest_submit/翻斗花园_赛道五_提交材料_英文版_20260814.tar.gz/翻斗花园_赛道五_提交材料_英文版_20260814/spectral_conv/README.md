# Required operator · Spectral convolution

This folder is the contest **required operator**: 2D spectral convolution (the core FNO layer).

Data goes to the frequency domain, low-frequency modes are kept, complex multiply runs on the GPU, then an inverse transform returns to space. The official hot path is **suFFT (on device) + a custom SUPA complex multiply**, not plain PyTorch.

## Before you start

```bash
source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh
export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2
cd spectral_conv
```

## 1. Build

```bash
./build.sh
```

This compiles `spectral_conv_ext.su` (SUPA kernel) and `spectral_conv_ext.cpp` (PyTorch Extension).

## 2. Accuracy

```bash
python3 test_accuracy.py
```

Relative error vs the reference must be ≤ `1e-4`. Current worst ≈ **2.17×10⁻⁷**.

## 3. Performance

```bash
python3 test_perf.py
```

Official sizes 64 / 128 / 256. Current idle ≈ **3.797 / 8.037 / 29.295 ms**.

Optional extra checks:

```bash
python3 test_backward.py
python3 test_3d_accuracy.py
python3 test_irregular_shapes.py
```

## 4. Advanced FNO demo

After the operator builds and accuracy passes:

```bash
cd ../fno_ns
python3 test_forward.py    # public-set relative L2 (≈ 0.035012)
python3 visualize.py       # prediction / ground truth / error
```

Weights: `fno_ns/checkpoints/fno_ns_public_demo.pt`.  
Public NS data (not in this pack): `fno_ns/data/navier_stokes_v1e-3_N1200_T20.pt`.

Figures land in `results/figures/` and a copy for judges is in `demo/media/`.

## Main files

| File | Role |
|------|------|
| `spectral_conv_ext.su` | SUPA frequency-domain complex multiply |
| `spectral_conv_ext.cpp` | Extension + suFFT wiring |
| `spectral_conv_ops.py` | Full forward (FFT → mul → iFFT) |
| `build.sh` | Build |
| `test_accuracy.py` | Accuracy |
| `test_perf.py` | Performance |
| `reference_pytorch.py` | CPU reference |
