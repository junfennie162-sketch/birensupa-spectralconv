# Demo

Flow-field figures and a short run snapshot.

Made by `fno_ns/render_official_demo.py`: official public NS64 + `fno_ns_public_demo.pt`, forward on the 1000/128 test split, then `visualize.py`. Quote relative L2 **0.035012** from `results.md`.

| File | What it is |
|------|------------|
| `media/fno_ns_pred_vs_gt_2026-08-14.png` | One sample: last input, GT, pred, error |
| `media/fno_ns_sample_strip_2026-08-14.png` | Best / median / worst in the batch |
| `media/brsmi_snapshot.txt` | Single-card run snapshot |
| `media/official_recheck_2026-08-14.log` | 08-14 recheck log |
| `media/metrics_snapshot.md` | Metric excerpt |
