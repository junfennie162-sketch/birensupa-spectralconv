# Metrics snapshot · 2026-08-14

## 正式（公开 NS64）

- 相对 L2：**0.035012**
- 数据：`fno_ns/data/navier_stokes_v1e-3_N1200_T20.pt`（训练 1000 / 测试 128，种子 20260722）
- 权重：`fno_ns/checkpoints/fno_ns_public_demo.pt`
- 图：`render_official_demo.py` 在上述官方测试划分上前向后，由 `visualize.py` 画出

## 频谱卷积（与 NS 数据无关）

- 耗时（2026-08-14）：**3.797 / 8.037 / 29.295 ms** @64/128/256
- 正确性最差相对误差：**2.170×10⁻⁷**（门槛 1×10⁻⁴）
