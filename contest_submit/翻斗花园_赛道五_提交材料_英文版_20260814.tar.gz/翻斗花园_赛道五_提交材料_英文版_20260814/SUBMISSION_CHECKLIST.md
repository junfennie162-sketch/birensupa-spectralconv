# Submission checklist

Official Track 5 required items only, plus the files we keep in this pack.

| Official requirement | Our file | Note |
|----------------------|----------|------|
| `skill.md` (required) | `skill.md` | Keep this filename |
| Source | `spectral_conv/`, `fno_ns/` | SUPA kernel + FNO |
| Dependencies and build / run | `README.md`; `spectral_conv/build.sh` | Source the env first |
| Accuracy scripts and results | `spectral_conv/test_accuracy.py`; `results/run_logs/` | Rel. error ≤ 1e-4 |
| Perf scripts and report | `spectral_conv/test_perf.py`; `results/run_logs/` | 64 / 128 / 256 |
| Run logs or screenshots | `results/run_logs/`; `demo/media/` | Includes `brsmi` snapshot |
| Agent log (≥5 records, ≥3 scenes) | `development_log.md`; `AGENT_OFFICIAL.md`; `agent_logs/` | Summary + raw chats |
| Results write-up | `results.md` | Official-data comparison and changes |
| Demo (recommended) | `demo/` | Official-data flow-field figures |

Keep these four filenames at the pack root: `README.md`, `skill.md`, `results.md`, `development_log.md`.
