# 数据目录

Put the public evaluation file here:

`navier_stokes_v1e-3_N1200_T20.pt`

It is **not** shipped in this tarball (size limit). Split: train 1000 / test 128, seed `20260722`.
