# Advanced model · FNO vorticity

This folder stacks a **≥4-layer FNO** on the required spectral-conv operator, and predicts 2D Navier–Stokes **vorticity** on the **official public NS64** file (frames 1–10 → frame 11).

Build the operator first: [`../spectral_conv/README.md`](../spectral_conv/README.md).

## Result

Public NS64 (split 1000/128) relative L2: **0.035012**.

## How the figures are made

`render_official_demo.py` loads the official `.pt` and `fno_ns_public_demo.pt`, runs the test split, writes `checkpoints/demo_batch.pt`, then calls `visualize.py`. Do not use `test_forward.py` as the demo entry (it defaults to a generated cache).

```bash
source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh
export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2
cd fno_ns
python3 render_official_demo.py
```

- Weights: `checkpoints/fno_ns_public_demo.pt`
- Data: `data/navier_stokes_v1e-3_N1200_T20.pt` (provide this file yourself)
- Model: `model.py` (4 layers, width=32, modes=16, 64×64)

## Main files

| File | Role |
|------|------|
| `model.py` | FNO; inference calls the required operator |
| `dataset.py` | Load and split |
| `render_official_demo.py` | Official data + public weights → figures |
| `visualize.py` | Draw from `demo_batch.pt` |
| `checkpoints/` | Pretrained weights |
| `data/` | Where to put the public `.pt` |
