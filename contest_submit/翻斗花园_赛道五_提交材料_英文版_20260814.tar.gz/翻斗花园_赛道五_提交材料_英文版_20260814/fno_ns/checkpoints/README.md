# Checkpoints

| File | Role |
|------|------|
| `fno_ns_public_demo.pt` | Official-dataset weights (public NS64, relative L2 **0.035012**) |
| `demo_batch.pt` | Small batch used by `visualize.py` |
