# skill.md · SpectralConv + FNO vorticity (Fandou Garden)

## Skill name

`spectral_conv_fno_ns_biren` (entry)

## Sub-skills

| Skill | Path | Role |
|-------|------|------|
| spectral-conv-dev | [`skills/spectral_conv_dev/`](skills/spectral_conv_dev/) | Build, accuracy, error checks |
| fno-experiment | [`skills/fno_experiment/`](skills/fno_experiment/) | Forward, metrics, plots |
| operator-opt-loop | [`skills/operator_opt_loop/`](skills/operator_opt_loop/) | Process self-check (`--dry-run --strict`) |
| fno-eval-protocol | [`skills/fno_eval_protocol.md`](skills/fno_eval_protocol.md) | Public-set eval protocol |

## Goal

Implement 2D spectral convolution (SUPA) on a Biren GPU, then assemble a ≥4-layer FNO for 2D Navier–Stokes vorticity.

## Inputs

- Operator: `x: [B, C_in, H, W]`, configurable `modes1/modes2`
- Model: multi-frame vorticity `[B, T_in, H, W]`; data file `fno_ns/data/navier_stokes_v1e-3_N1200_T20.pt`

## Steps

1. `source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh`
2. `export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2`
3. `cd spectral_conv && ./build.sh`
4. `python3 test_accuracy.py` (relative error ≤ 1e-4)
5. `python3 test_perf.py` (64 / 128 / 256)
6. `cd ../fno_ns && python3 test_forward.py && python3 visualize.py`
7. Agent review: `AGENT_OFFICIAL.md`, `development_log.md`

Walkthrough: [`spectral_conv/README.md`](spectral_conv/README.md).

## Outputs

- Accuracy / perf in `results/summary.json`
- Figures in `results/figures/` and `demo/media/`
- Headline: public relative L2 **0.035012**; spectral-conv **3.797 / 8.037 / 29.295 ms**

## Limits

- Official hot path: on-device suFFT + SUPA complex multiply (not plain PyTorch)
- Official metric uses public NS64 (1000 / 128); weights `fno_ns/checkpoints/fno_ns_public_demo.pt`
