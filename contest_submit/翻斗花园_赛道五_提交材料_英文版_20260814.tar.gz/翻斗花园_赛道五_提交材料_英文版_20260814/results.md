# Test results

This file has two parts: **comparisons** (official setup vs our optimized code on that same setup) and **what we changed in the operator / model**. We did not swap the evaluation dataset.

Unedited terminal output: `results/run_logs/` (see that folder’s README). Unedited Cursor chats: `agent_logs/`.

## 1. Performance and correctness

### 1.1 Required operator: official reference vs our optimized implementation

Spectral convolution follows the official operator protocol and does not read Navier–Stokes data. Correctness is vs the official-style PyTorch reference. Performance is vs the official CPU baseline script on this machine.

| Item | Official / reference | Ours after optimization (SUPA + Extension) | Note |
|------|----------------------|--------------------------------------------|------|
| Correctness (worst rel. error) | limit ≤ `1e-4` | **2.170×10⁻⁷** (3/3 PASS) | vs `reference_pytorch.py` |
| 64×64 forward | 74.142 ms (CPU) | **3.797 ms** | ~19.5× |
| 128×128 forward | 89.000 ms (CPU) | **8.037 ms** | ~11.1× |
| 256×256 forward | 295.983 ms (CPU) | **29.295 ms** | ~10.1× |

Raw logs (not edited):

| File | What it is | Related to |
|------|------------|------------|
| `results/run_logs/official_recheck_2026-08-14.log` | One terminal session on 2026-08-14 | Build + accuracy + perf + **official-data** FNO reeval |
| `results/run_logs/spectral_accuracy_2026-08-14.md` | Dump from `test_accuracy.py` | Operator vs reference |
| `results/run_logs/spectral_perf_2026-08-14.md` | Dump from `test_perf.py` | Operator 64/128/256 |
| `results/run_logs/official_baseline_2026-07-21.md` | Official CPU baseline output | The 74 / 89 / 296 ms numbers |

### 1.2 Advanced model: official dataset, before vs after our optimization

The data is always the official public NS64 file `navier_stokes_v1e-3_N1200_T20.pt`. **We did not change this file.**

| Item | Official setup | Our result on the official data |
|------|----------------|---------------------------------|
| Data | `navier_stokes_v1e-3_N1200_T20.pt` (public NS64) | **Same file, unchanged** |
| Split | train 1000 / test 128, seed `20260722` | Same protocol |
| Task | frames 1–10 → frame 11, 64×64, ≥4-layer FNO | 4 layers, width=32, modes=16 |
| Relative L2 (official score) | lower is better | **0.035012** |
| Same official data, optimization | **0.041835** when we first hooked up the official set | **0.035012** (~16.3% relative drop) |
| Weights | — | `fno_ns/checkpoints/fno_ns_public_demo.pt` |
| Raw log | — | FNO REEVAL in `official_recheck_2026-08-14.log`; `fno_public_spec_ref_r2_20260811_095727.log` |

The contest score is **0.035012**. To reproduce figures: build the operator, then `python3 render_official_demo.py` in `fno_ns/` (you need the official `.pt` file).

## 2. What we changed

### 2.1 Operator: fused on-device path instead of copying the spectrum back to CPU

The early path did FFT on the host, multiplied the full spectrum on CPU, and copied back. At 64/128, **host↔device copies** dominated.

Official hot path now:

1. **suFFT R2C on device**; the spectrum stays on the GPU.
2. **Custom SUPA kernel** for the official dual-corner complex multiply (kept modes only).
3. **On-device C2R**. Code: `spectral_conv/`.

Also: weight/spectrum caches, output-buffer reuse, and a size-based path (tiny maps: CPU FFT + device mul; larger maps: fused). Correctness vs the official-style reference: worst rel. **2.170×10⁻⁷**. Extra checks: backward, 3-D corners, irregular shapes. Time vs this machine’s official CPU baseline: 74.142 / 89.000 / 295.983 ms → **3.797 / 8.037 / 29.295 ms**.

### 2.2 FNO: reuse that operator, train on the official file

Four Fourier layers; inference calls the same operator. Residual head (predict the increment vs the last input frame). **The official `.pt` was not edited.** Relative L2 was **0.041835** when we first used this file; later, on the same split: periodic roll aug, spectral-weighted loss, and a late stage that mainly updates spectral weights with an H⁻¹-style term. Official score **0.035012**.

Figures: `fno_ns/render_official_demo.py` forwards the official test split, then `visualize.py` draws them.
