# Fandou Garden · Track 5

Shusheng Guozhi Science Challenge · Biren Flying Cup · **Track 5 (Models & Operators)**  
Team: **Fandou Garden** (North University of China)

This submission does two things on a single **Biren106B** GPU:

1. **Required operator** — 2D spectral convolution (the FNO core) in SUPA + PyTorch Extension.
2. **Advanced model** — a ≥4-layer FNO that predicts 2D incompressible Navier–Stokes **vorticity**, with figures.

Agent-assisted development. **Raw chats** are in `agent_logs/`; **raw run logs** are in `results/run_logs/`. Summaries: `development_log.md`.

## Results

| Item | Result |
|------|--------|
| Spectral-conv relative error | worst ≈ **2.17×10⁻⁷** (limit 1×10⁻⁴) |
| Spectral-conv time 64 / 128 / 256 | **3.797 / 8.037 / 29.295 ms** |
| FNO public NS64 relative L2 | **0.035012** |

Full tables: `results.md`.

## Layout

| Folder | Contents |
|--------|----------|
| `spectral_conv/` | Operator source, build, tests. **Start with its README.** |
| `fno_ns/` | FNO model, weights, forward + plots |
| `demo/` | Figures and run snapshots |
| `results/` | Numbers and figures |
| `results/run_logs/` | Raw terminal logs (each file labeled) |
| `agent_logs/` | Raw Cursor chats (jsonl, unedited) |
| `skills/` | Official skill notes |
| `scripts/` | One-shot test helpers |

Official filenames at the pack root (do not rename): `README.md`, `skill.md`, `results.md`, `development_log.md`.

## How to run

```bash
source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh
export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2

cd spectral_conv
./build.sh
python3 test_accuracy.py
python3 test_perf.py

cd ../fno_ns
python3 render_official_demo.py
```

Details: [`spectral_conv/README.md`](spectral_conv/README.md) and [`fno_ns/README.md`](fno_ns/README.md).

The public NS `.pt` file is **not** inside this pack (size limit). Place it at `fno_ns/data/navier_stokes_v1e-3_N1200_T20.pt` before the FNO eval.

Device name is `supa` (import `torch_br` first). `torch.cuda.is_available()` being False is expected.
