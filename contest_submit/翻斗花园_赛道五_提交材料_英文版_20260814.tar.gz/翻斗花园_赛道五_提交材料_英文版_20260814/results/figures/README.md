# Flow-field figures

These are vorticity **flow-field** plots (prediction / ground truth / error), not software flowcharts.

They come from `fno_ns/visualize.py`. That script reads `checkpoints/demo_batch.pt`, which is one forward batch on the **official** public NS64 test split using `fno_ns_public_demo.pt` (inputs, ground truth, prediction).

| File | Content |
|------|---------|
| `fno_ns_pred_vs_gt_2026-08-02.png` | One sample: last input, GT, pred, error |
| `fno_ns_sample_strip_2026-08-02.png` | Best / median / worst test samples |

Same protocol as the official score: `navier_stokes_v1e-3_N1200_T20.pt`, 1000/128. The number to quote is relative L2 **0.035012** in `results.md`.
