# Run logs (unedited)

These files were written by scripts or the terminal. **Numbers were not edited afterwards.** The table says what each file is.

| File | What this log is | Related to |
|------|------------------|------------|
| `official_recheck_2026-08-14.log` | Full terminal session, 2026-08-14 | Build, accuracy, perf, public FNO reeval (L2 0.035012) |
| `brsmi_snapshot.txt` | `brsmi` snapshot | GPU idle on Biren106B during the recheck |
| `spectral_accuracy_2026-08-14.md` | Dump from `test_accuracy.py` | Operator vs reference, worst rel 2.17×10⁻⁷ |
| `spectral_perf_2026-08-14.md` | Dump from `test_perf.py` | Operator 3.797 / 8.037 / 29.295 ms |
| `正确性验证报告_2026-08-14.md` | Short report from the accuracy log | Same numbers, easier to read |
| `性能检测报告_2026-08-14.md` | Short report from the perf log | Same numbers, easier to read |
| `official_baseline_2026-07-21.md` | Official CPU baseline script | 74.142 / 89.000 / 295.983 ms |
| `official_baseline_2026-07-21.json` | Same, JSON | Same |
| `spectral_accuracy_idle_2026-07-31.log` | Earlier idle accuracy terminal | Same accuracy protocol |
| `spectral_perf_idle_2026-07-31.log` | Earlier idle perf terminal | Then 3.811 / 8.054 / 29.560 ms |
| `spectral_backward_2026-08-02.md` | Backward test dump | Gradients, worst rel ≈ 6.25×10⁻⁸ |
| `spectral_3d_accuracy_2026-08-04.md` | 3-D corner accuracy | Operator extra, not a 3-D FNO |
| `fno_public_spec_ref_r2_20260811_095727.log` | Public-set train/eval terminal | **Official dataset** → L2 0.035012 |
| `fno_batch16_benchmark_public_ns64_2026-08-03.md` | Batch-16 forward throughput | Public set + official weights |
| `fno_train_throughput_2026-07-25.md` | Train-step throughput | Includes loss / backward / Adam |
| `fno_supa_chain_2026-07-24.md` | FNO device chain vs CPU | Inference consistency |
| `fno_chain_consistency_2026-07-25.md` | Gate record for that chain | Rel. error vs 1e-4 |
| `fno_forward_2026-07-23.md` | Early FNO forward | Model runs |
| `env_baseline_2026-07-21.md` | Env / GEMV baseline | SDK and device |
| `operator_opt_loop_last.json` | Asset self-check | Submit-gate dry-run |

Raw Cursor chats are in `../agent_logs/` (English pack) or `交互日志/` (Chinese pack).
