# Results folder

| File / folder | What it is |
|---------------|------------|
| `summary.json` | Accuracy, timings, official-data L2 |
| `phase_status.json` | Phase status |
| `评测报告_最新指标_2026-08-14_095200.md` | Latest metrics (no version chain) |
| `figures/` | Official-data prediction / GT / error plots |
| `run_logs/` | **Raw logs** (see that folder’s README) |

Comparisons and changes: `../results.md`. Raw Cursor chats: `../agent_logs/`.
