# Agent interaction logs (unedited)

These are raw Cursor Agent chats (jsonl). They were not rewritten into summaries. Open them in a text editor to see the original user prompts and replies.

| File | What it is | Related to |
|------|------------|------------|
| `8258b9af-17b1-4d78-89fc-12fd826b64e9.jsonl` | Full chat, 2026-07-31 | Which tree is primary; public vs modified L2 |
| `b2a7a02d-aa1c-4a6a-bb3b-d59c969db60e.jsonl` | Full chat, 2026-08-02 | Next operator/model optimization round |

The 6 formatted records in `development_log.md` and `AGENT_OFFICIAL.md` are for reading. **This folder is the raw evidence.**

Terminal logs live in `../results/run_logs/`.
