# Development log (Agent-assisted)

> Official required item. **Evidence files first**, then 6 interaction records (kernel / bottleneck / hyperparam / data / viz / platform).  
> Tool: Cursor Agent (SSH · Biren contest Docker · SDK `1.11.0.0.rc2`).

## Direct evidence (unedited)

Prose is not evidence. Open these files:

| File | What it is | Related to |
|------|------------|------------|
| [`agent_logs/8258b9af-17b1-4d78-89fc-12fd826b64e9.jsonl`](agent_logs/8258b9af-17b1-4d78-89fc-12fd826b64e9.jsonl) | Raw Cursor chat (jsonl, unedited) | Which workspace is primary; metrics at the time |
| [`agent_logs/b2a7a02d-aa1c-4a6a-bb3b-d59c969db60e.jsonl`](agent_logs/b2a7a02d-aa1c-4a6a-bb3b-d59c969db60e.jsonl) | Raw Cursor chat (jsonl, unedited) | Next optimization round from the metrics report |
| [`results/run_logs/official_recheck_2026-08-14.log`](results/run_logs/official_recheck_2026-08-14.log) | One full terminal **log** | Build + accuracy + perf + **official-data** FNO |
| [`results/run_logs/fno_public_spec_ref_r2_20260811_095727.log`](results/run_logs/fno_public_spec_ref_r2_20260811_095727.log) | Train/eval **log** | Official dataset → L2 0.035012 |
| [`results/run_logs/README.md`](results/run_logs/README.md) | Catalog | Label for every log |

Formatted summary (not the raw file): [`AGENT_OFFICIAL.md`](AGENT_OFFICIAL.md).

---

## Agent record 1 · Kernel

- Tool / Agent: Cursor Agent (SSH)
- Scene: operator kernel design / debug / optimize
- Goal: spectral conv on SUPA, relative error ≤ 1e-4
- Prompt summary: core math must be SUPA / Extension, not plain PyTorch
- Agent suggestion: suFFT → SUPA multiply → iFFT on device
- Adopted: `spectral_conv/spectral_conv_ext.su`, `.cpp`, `spectral_conv_ops.py`
- Evidence: `results/run_logs/spectral_accuracy_2026-08-14.md`, worst rel **2.170×10⁻⁷**
- Not adopted: `torch.fft` on `device=supa` (breaks 1e-4)

## Agent record 2 · Bottleneck

- Tool / Agent: Cursor Agent (SSH)
- Scene: performance bottleneck
- Goal: cut 64/128/256 time
- Prompt summary: keep optimizing; why are small sizes slow
- Agent suggestion: copies, not FLOPs
- Adopted: fused path, buffer reuse; idle `test_perf.py`
- Evidence: `results/run_logs/spectral_perf_2026-08-14.md` → **3.797 / 8.037 / 29.295 ms**; CPU baseline `official_baseline_2026-07-21.md`
- Not adopted: `torch.fft@SUPA` as the official path

## Agent record 3 · Hyperparameters

- Tool / Agent: Cursor Agent (SSH)
- Scene: architecture / hyperparameter search
- Goal: lower public NS64 relative L2
- Prompt summary: push accuracy; do not promote failed probes
- Agent suggestion: train spectral weights only + spectral loss
- Adopted: `fno_ns/checkpoints/fno_ns_public_demo.pt`
- Evidence: `fno_public_spec_ref_r2_20260811_095727.log`, L2 **0.035012**; reeval in `official_recheck_2026-08-14.log`
- Not adopted: failed-probe checkpoints as the official score

## Agent record 4 · Data

- Tool / Agent: Cursor Agent (SSH)
- Scene: data / features
- Goal: official score uses public NS64 only
- Prompt summary: submit on the public set; disclose source
- Agent suggestion: loader prefers the official `.pt`; lock split 1000/128, seed 20260722
- Adopted: `navier_stokes_v1e-3_N1200_T20.pt`; official weights `fno_ns_public_demo.pt`
- Evidence: official-data relative L2 **0.035012**; FNO REEVAL in `official_recheck_2026-08-14.log`
- Not adopted: treating non-official-data numbers as the contest score

## Agent record 5 · Visualization

- Tool / Agent: Cursor Agent (SSH)
- Scene: analysis / plots
- Goal: prediction / ground truth / error figures
- Prompt summary: figures for reviewers
- Agent suggestion: shared color scale; best/median/worst strip
- Adopted: `fno_ns/visualize.py`; `demo/media/`
- Evidence: `demo/media/fno_ns_pred_vs_gt_2026-08-02.png`
- Not adopted: using non-official-eval figures as the public demo

## Agent record 6 · Biren platform

- Tool / Agent: Cursor Agent (SSH)
- Scene: BIREN GPU adaptation
- Goal: reproducible on one Biren106B
- Prompt summary: source the env; one GPU job at a time
- Agent suggestion: device name `supa`; `torch.cuda.is_available()` False is expected
- Adopted: `brsmi` snapshot before the recheck
- Evidence: `results/run_logs/brsmi_snapshot.txt` and the BR-SMI header in `official_recheck_2026-08-14.log`
- Not adopted: running two workspaces on the GPU at once
