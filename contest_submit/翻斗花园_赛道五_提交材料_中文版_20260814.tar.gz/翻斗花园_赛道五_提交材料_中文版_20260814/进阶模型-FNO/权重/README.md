# 权重

| 文件 | 说明 |
|------|------|
| `fno_ns_public_demo.pt` | 官方数据集上的正式权重（公开 NS64，相对 L2 **0.035012**） |
| `demo_batch.pt` | 画图用的一小批样本 |

把公开数据放到上级 `数据/` 后，运行：

```bash
cd ..
python3 test_forward.py
python3 visualize.py
```
