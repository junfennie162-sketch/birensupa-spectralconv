# 进阶模型 · FNO 涡度预测

本目录在必选频谱卷积之上，搭建 **≥4 层 FNO**，在**官方公开 NS64** 上做二维涡度单步预测（前 10 帧 → 第 11 帧）。

请先按 [`../必选算子-卷积/README.md`](../必选算子-卷积/README.md) 完成编译。

## 结果

公开 NS64（划分 1000/128）相对 L2：**0.035012**。

## 怎么生成演示图

图由 `render_official_demo.py` 生成：读官方 `.pt` + 正式权重，在测试集上前向，再调用 `visualize.py`。不要用 `test_forward.py` 当演示入口（它默认走自建缓存）。

```bash
source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh
export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2
cd 进阶模型-FNO
python3 render_official_demo.py
```

- 权重：`权重/fno_ns_public_demo.pt`
- 数据：`数据/navier_stokes_v1e-3_N1200_T20.pt`（需自备公开集文件）
- 模型：`model.py`（4 层，width=32，modes=16，64×64）

## 主要文件

| 文件 | 作用 |
|------|------|
| `model.py` | FNO 网络，推理时调用必选算子 |
| `dataset.py` | 数据加载与划分 |
| `render_official_demo.py` | 官方数据 + 正式权重 → 流场图 |
| `visualize.py` | 根据 `demo_batch.pt` 画图 |
| `权重/` | 预训练 checkpoint |
| `数据/` | 数据放置目录（说明见该目录 README） |
