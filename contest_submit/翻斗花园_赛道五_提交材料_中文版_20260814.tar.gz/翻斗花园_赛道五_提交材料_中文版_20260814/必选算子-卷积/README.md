# 必选算子 · 频谱卷积

本目录是赛题**必选算子**：二维频谱卷积（FNO 里的核心层）。

数据从空间域变到频域，只保留低频 modes，在 GPU 上做复数乘法，再变回空间域。正式热路径是：**suFFT（设备上）+ 自研 SUPA 复数乘**，而不是纯原生 PyTorch。

## 使用前

```bash
source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh
export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2
cd 必选算子-卷积
```

## 一、编译源码

```bash
./build.sh
```

会把 `spectral_conv_ext.su`（SUPA kernel）和 `spectral_conv_ext.cpp`（PyTorch Extension）编成可调用模块。

## 二、正确性

```bash
python3 test_accuracy.py
```

与参考实现对比，相对误差须 ≤ `1e-4`。当前最差约 **2.17×10⁻⁷**。

## 三、性能

```bash
python3 test_perf.py
```

官方三档分辨率 64 / 128 / 256。当前 idle 约 **3.797 / 8.037 / 29.295 毫秒**。

可选扩展（评委抽查用，不是主报）：

```bash
python3 test_backward.py          # 反向
python3 test_3d_accuracy.py       # 三维四角
python3 test_irregular_shapes.py  # 不规则尺寸
```

## 四、进阶模型演示（FNO 涡度）

算子编过、正确性通过后，到上一级的进阶目录做模型演示：

```bash
cd ../进阶模型-FNO
python3 test_forward.py    # 公开集前向，报告相对 L2（约 0.035012）
python3 visualize.py       # 画出预测 / 真值 / 误差
```

预训练权重在 `进阶模型-FNO/权重/fno_ns_public_demo.pt`。  
公开 NS 数据文件若包内没有，请自行放到 `进阶模型-FNO/数据/navier_stokes_v1e-3_N1200_T20.pt`。

图会写到 `测试结果/流场图/`，演示目录里也有一份给评委看的图：`演示与展示/媒体/`。

## 主要文件

| 文件 | 作用 |
|------|------|
| `spectral_conv_ext.su` | SUPA 频域复数乘 kernel |
| `spectral_conv_ext.cpp` | Extension 与 suFFT 拼接 |
| `spectral_conv_ops.py` | 组出完整前向（FFT → 乘 → iFFT） |
| `build.sh` | 编译 |
| `test_accuracy.py` | 正确性 |
| `test_perf.py` | 性能 |
| `reference_pytorch.py` | CPU 参考 |

更细的指标记录见上级目录 `results.md` 与 `测试结果/运行日志/`。
