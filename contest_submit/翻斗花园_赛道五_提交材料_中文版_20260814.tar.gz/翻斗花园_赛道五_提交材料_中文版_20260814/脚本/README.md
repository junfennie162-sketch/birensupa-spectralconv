# 脚本

常用一键命令（请先 `source` 环境脚本，且同一时间只跑一张卡）：

```bash
./脚本/run_tests.sh accuracy   # 编译 + 正确性
./脚本/run_tests.sh perf       # 性能
./脚本/run_tests.sh fno        # FNO 前向 + 画图
./脚本/run_demo.sh             # 演示入口
```

第一次用建议先按 [`必选算子-卷积/README.md`](../必选算子-卷积/README.md) 逐步跑通。
