#!/usr/bin/env bash
# 串行跑必选 + 进阶正确性；结束后跑资产维护检查（不自动 mark-done）
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# shellcheck disable=SC1091
source "${ROOT}/脚本/setup_env.sh"

echo "[1/2] spectral_conv accuracy"
if [[ -f "${ROOT}/必选算子-卷积/test_accuracy.py" ]]; then
  (cd "${ROOT}/必选算子-卷积" && ./build.sh && python3 test_accuracy.py)
else
  echo "SKIP: spectral_conv not implemented yet"
fi

echo "[2/2] fno_ns forward"
if [[ -f "${ROOT}/进阶模型-FNO/test_forward.py" ]]; then
  (cd "${ROOT}/进阶模型-FNO" && python3 test_forward.py)
else
  echo "SKIP: fno_ns not implemented yet"
fi

echo "[assets] phase status / next checklist"
"${ROOT}/脚本/maintain_assets.sh" status
"${ROOT}/脚本/maintain_assets.sh" next

echo "done"
echo "tip: after metrics are written, run: ./脚本/maintain_assets.sh mark-done <phase>"
