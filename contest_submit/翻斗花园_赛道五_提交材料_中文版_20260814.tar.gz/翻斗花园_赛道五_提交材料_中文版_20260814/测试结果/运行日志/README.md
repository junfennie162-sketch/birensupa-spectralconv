# 运行日志（原文未改）

这里都是脚本/终端当时写下的文件，**没有事后改数字**。下面标明每份是什么、跟哪项结果有关系。

| 文件名 | 这是什么 log | 跟什么有关系 |
|--------|--------------|--------------|
| `official_recheck_2026-08-14.log` | 2026-08-14 一次终端全程 | 编译算子、正确性、性能、公开集 FNO 复评（L2 0.035012） |
| `brsmi_snapshot.txt` | `brsmi` 单卡快照 | 证明复测时 GPU 空闲（Biren106B） |
| `spectral_accuracy_2026-08-14.md` | `test_accuracy.py` 自己写的结果 | 必选算子 vs 参考实现，worst rel 2.17×10⁻⁷ |
| `spectral_perf_2026-08-14.md` | `test_perf.py` 自己写的结果 | 必选算子 3.797 / 8.037 / 29.295 ms |
| `正确性验证报告_2026-08-14.md` | 根据上面正确性 log 整理的报告 | 方便阅读；数字与机打 log 一致 |
| `性能检测报告_2026-08-14.md` | 根据上面性能 log 整理的报告 | 方便阅读；数字与机打 log 一致 |
| `official_baseline_2026-07-21.md` | 官网 CPU 参考脚本输出 | 对比用的 74.142 / 89.000 / 295.983 ms |
| `official_baseline_2026-07-21.json` | 同上，JSON 原文 | 同上 |
| `spectral_accuracy_idle_2026-07-31.log` | 更早一次空闲正确性终端 | 必选算子正确性（与 08-14 同协议） |
| `spectral_perf_idle_2026-07-31.log` | 更早一次空闲性能终端 | 当时 3.811 / 8.054 / 29.560 ms |
| `spectral_backward_2026-08-02.md` | 反向测试脚本输出 | 算子梯度，worst rel ≈ 6.25×10⁻⁸ |
| `spectral_3d_accuracy_2026-08-04.md` | 三维四角正确性 | 算子扩展，不是完整 3D FNO |
| `fno_public_spec_ref_r2_20260811_095727.log` | 公开集训练/评测终端 | **官方数据集**上做到相对 L2 0.035012 |
| `fno_batch16_benchmark_public_ns64_2026-08-03.md` | batch=16 前向吞吐 | 公开集 + 正式权重 |
| `fno_train_throughput_2026-07-25.md` | 训练步吞吐 | 含 loss / backward / Adam |
| `fno_supa_chain_2026-07-24.md` | FNO 设备链 vs CPU | 推理路径一致性 |
| `fno_chain_consistency_2026-07-25.md` | 同上的门禁记录 | 相对误差过 1e-4 |
| `fno_forward_2026-07-23.md` | 早期 FNO 前向 | 进阶模型能跑通 |
| `env_baseline_2026-07-21.md` | 环境/GEMV 基线 | SDK、设备、方式二可用 |
| `operator_opt_loop_last.json` | 材料自检脚本输出 | 提交门禁 dry-run |

Cursor 对话原文不在本目录，在上级的 `交互日志/`（中文包）或 `agent_logs/`（英文包）。
