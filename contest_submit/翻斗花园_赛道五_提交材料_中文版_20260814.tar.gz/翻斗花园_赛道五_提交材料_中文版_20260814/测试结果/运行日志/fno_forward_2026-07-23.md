# FNO-NS forward (strengthened vs official L2 weight)

- time_utc: 2026-07-23T13:16:48Z
- data: generated_ns_like_v2
- fourier_layers: 4
- n_train/n_test/total_epochs: 768/128/~110 (resume +50 on prior ckpt)
- rel_l2_supa: 0.00951623567380011
- rel_l2_torch: 0.00951623497530818
- figure: 测试结果/流场图/fno_ns_pred_vs_gt_2026-07-23.png
- resume_log: 测试结果/运行日志/fno_resume_l2_2026-07-23.log
