# 流场图

这里是涡度**流场对比图**（预测 / 真值 / 误差），不是开发流程图。

由 `进阶模型-FNO/visualize.py` 画出。输入是 `权重/demo_batch.pt`：官方公开 NS64 测试集上，用正式权重 `fno_ns_public_demo.pt` 做前向，把一批 input / 真值 / 预测存下来，再画图。

| 文件 | 内容 |
|------|------|
| `fno_ns_pred_vs_gt_2026-08-02.png` | 单样本：输入末帧、真值、预测、误差 |
| `fno_ns_sample_strip_2026-08-02.png` | 最好 / 中位 / 最差三个测试样本 |

协议与正式成绩相同：`navier_stokes_v1e-3_N1200_T20.pt`，1000/128。数字以 `results.md` 的相对 L2 **0.035012** 为准。
