# 翻斗花园 · 赛道五作品说明

书生国智科探挑战赛 · 壁仞飞翔杯 · **赛道五（模型与算子）**  
队伍：**翻斗花园**（中北大学）

本作品在壁仞 **Biren106B** 单卡上完成两件事：

1. **必选算子**：用 SUPA + PyTorch Extension 实现 FNO 核心的二维频谱卷积（Spectral Convolution）。
2. **进阶模型**：用该算子搭 ≥4 层 FNO，预测二维不可压 Navier-Stokes **涡度场**，并给出可视化。

开发过程由 Cursor Agent 辅助。**原始对话**在 `交互日志/`，**原始运行 log** 在 `测试结果/运行日志/`；摘要见 `development_log.md`。

## 结果（现行）

| 项目 | 结果 |
|------|------|
| 频谱卷积正确性（相对误差） | 最差约 **2.17×10⁻⁷**（门槛 1×10⁻⁴） |
| 频谱卷积耗时 64 / 128 / 256 | **3.797 / 8.037 / 29.295 毫秒** |
| FNO 公开 NS64 相对 L2 | **0.035012** |

更完整的数字表见 `results.md`。

## 目录怎么看

| 文件夹 | 里面是什么 |
|--------|------------|
| `必选算子-卷积/` | 算子源码、编译与测试。**请先读这里的 README** |
| `进阶模型-FNO/` | FNO 模型、权重、前向与画图 |
| `演示与展示/` | 流场对比图、运行快照 |
| `测试结果/` | 数字汇总、流场图 |
| `测试结果/运行日志/` | 原始终端 log（每份都有标注） |
| `交互日志/` | Cursor 原始对话 jsonl（未改） |
| `技能文档/` | 官方要求的 skill 拆分说明 |
| `脚本/` | 一键测试等辅助脚本 |

根目录需要保留英文文件名的官方文件：`README.md`、`skill.md`、`results.md`、`development_log.md`。

## 建议阅读顺序

1. 本页（项目介绍）
2. [`必选算子-卷积/README.md`](必选算子-卷积/README.md)（怎么编译、怎么跑）
3. [`进阶模型-FNO/README.md`](进阶模型-FNO/README.md)（怎么做模型演示）
4. `results.md`（同一官方数据上的对比，以及我们改了什么）
5. `测试结果/运行日志/README.md`（每份 log 是什么）
6. `交互日志/`（原始 Agent 对话）
7. `演示与展示/媒体/` 里的预测对比图

## 环境

每个新终端先执行：

```bash
source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh
export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2
```

设备名是 `supa`（先 `import torch_br`）。`torch.cuda.is_available()` 为 False 是正常现象。
