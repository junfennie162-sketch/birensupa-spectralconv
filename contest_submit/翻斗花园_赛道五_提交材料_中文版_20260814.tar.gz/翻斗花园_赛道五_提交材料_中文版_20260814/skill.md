# skill.md · 频谱卷积 + FNO 涡度（翻斗花园）

## Skill 名称

`spectral_conv_fno_ns_biren`（总入口）

## 子 Skill 索引

| Skill | 路径 | 用途 |
|-------|------|------|
| 算子开发 | [`技能文档/算子开发/`](技能文档/算子开发/) | 编译、正确性、误差排查 |
| FNO 实验 | [`技能文档/FNO实验/`](技能文档/FNO实验/) | 前向、指标、可视化 |
| 优化闭环 | [`技能文档/优化闭环/`](技能文档/优化闭环/) | 规范自检（`--dry-run --strict`） |
| 评测协议 | [`技能文档/fno_eval_protocol.md`](技能文档/fno_eval_protocol.md) | 公开集评测口径 |

## 目标

在壁仞 BIREN GPU 上实现 FNO 核心的二维频谱卷积（SUPA），并组装不少于 4 层的 FNO，完成二维 Navier-Stokes 涡度预测。

## 输入

- 算子：张量 `x: [B, C_in, H, W]`，可配置 `modes1/modes2`
- 模型：多帧涡度 `[B, T_in, H, W]`；数据文件 `进阶模型-FNO/数据/navier_stokes_v1e-3_N1200_T20.pt`

## 步骤

1. `source /usr/local/birensupa/sdk/1.11.0.0.rc2/scripts/brsw_set_env.sh`
2. `export SUPA_BASE=/usr/local/birensupa/sdk/1.11.0.0.rc2`
3. `cd 必选算子-卷积 && ./build.sh`
4. `python3 test_accuracy.py`（相对误差 ≤ 1e-4）
5. `python3 test_perf.py`（64 / 128 / 256）
6. `cd ../进阶模型-FNO && python3 test_forward.py && python3 visualize.py`
7. Agent 抽查：根目录 `AGENT_OFFICIAL.md`、`development_log.md`

逐步说明见 [`必选算子-卷积/README.md`](必选算子-卷积/README.md)。

## 输出

- 正确性 / 性能写入 `测试结果/summary.json`
- 流场图：`测试结果/流场图/`、`演示与展示/媒体/`
- 主报：公开相对 L2 **0.035012**；频谱卷积耗时 **3.797 / 8.037 / 29.295 毫秒**

## 能力边界

- 正式热路径：设备上 suFFT + SUPA 复数乘，不是纯原生 PyTorch
- 正式主报用公开 NS64（训练 1000 / 测试 128）；权重 `进阶模型-FNO/权重/fno_ns_public_demo.pt`
