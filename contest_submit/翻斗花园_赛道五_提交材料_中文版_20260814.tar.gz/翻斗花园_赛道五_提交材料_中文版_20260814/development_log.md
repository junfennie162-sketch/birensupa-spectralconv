# 开发记录（Agent 辅助）

> 官方必须项。下面先放**直接证据文件**，再写 6 段交互（覆盖 kernel / 瓶颈 / 超参 / 数据 / 可视化 / 平台）。  
> 工具：Cursor Agent（SSH · 壁仞竞赛 Docker · SDK `1.11.0.0.rc2`）。

## 直接证据（未改原文）

文字摘要不是证据。请直接打开这些文件：

| 文件 | 这是什么 | 跟什么有关系 |
|------|----------|--------------|
| [`交互日志/8258b9af-17b1-4d78-89fc-12fd826b64e9.jsonl`](交互日志/8258b9af-17b1-4d78-89fc-12fd826b64e9.jsonl) | Cursor **原始对话**（jsonl，未改） | 确认主力工作区与当时指标 |
| [`交互日志/b2a7a02d-aa1c-4a6a-bb3b-d59c969db60e.jsonl`](交互日志/b2a7a02d-aa1c-4a6a-bb3b-d59c969db60e.jsonl) | Cursor **原始对话**（jsonl，未改） | 按评测报告开新一轮算子/模型优化 |
| [`测试结果/运行日志/official_recheck_2026-08-14.log`](测试结果/运行日志/official_recheck_2026-08-14.log) | 一次终端跑完的 **log** | 编译 + 正确性 + 性能 + **官方数据** FNO |
| [`测试结果/运行日志/fno_public_spec_ref_r2_20260811_095727.log`](测试结果/运行日志/fno_public_spec_ref_r2_20260811_095727.log) | 训练/评测 **log** | 官方数据集 → L2 0.035012 |
| [`测试结果/运行日志/README.md`](测试结果/运行日志/README.md) | 运行日志目录说明 | 每份 log 的标注 |

抽查页（格式化摘要，不是原始文件）：[`AGENT_OFFICIAL.md`](AGENT_OFFICIAL.md)。

---

## Agent 交互记录 1 · 算子 kernel

- 工具 / Agent：Cursor Agent（SSH）
- 场景标签：算子 kernel 设计/调试/优化
- 目标：频谱卷积走 SUPA，相对误差 ≤ 1e-4
- 关键提示词或交互摘要：核心计算必须在 SUPA / Extension 上，禁止只交原生 PyTorch
- Agent 建议：suFFT → SUPA 复数乘 → iFFT 串在设备上
- 采纳的修改：`必选算子-卷积/spectral_conv_ext.su`、`.cpp`、`spectral_conv_ops.py`
- 验证结果：见原始 log `测试结果/运行日志/spectral_accuracy_2026-08-14.md`，worst rel **2.170×10⁻⁷**
- 未采纳内容及原因：未把 `torch.fft` 直接跑在 `device=supa`（会偏出 1e-4）

## Agent 交互记录 2 · 性能瓶颈

- 工具 / Agent：Cursor Agent（SSH）
- 场景标签：性能瓶颈分析与定位
- 目标：把 64/128/256 耗时压下来
- 关键提示词或交互摘要：继续优化算子耗时；问小分辨率为何慢
- Agent 建议：主因是反复拷显存，不是算力不够
- 采纳的修改：fused 路径、buffer 复用；`test_perf.py` 空闲复测
- 验证结果：原始 log `测试结果/运行日志/spectral_perf_2026-08-14.md` → **3.797 / 8.037 / 29.295 ms**；对比官网 CPU 见 `official_baseline_2026-07-21.md`
- 未采纳内容及原因：未把 `torch.fft@SUPA` 当正式路径

## Agent 交互记录 3 · 超参与精度

- 工具 / Agent：Cursor Agent（SSH）
- 场景标签：模型架构选型与超参搜索
- 目标：公开 NS64 上压相对 L2
- 关键提示词或交互摘要：继续冲精度；未过线的权重不要写进正式 demo
- Agent 建议：只训 spectral 权重 + 频域损失（Spectral-Refiner）
- 采纳的修改：公开集权重 `进阶模型-FNO/权重/fno_ns_public_demo.pt`
- 验证结果：原始 log `fno_public_spec_ref_r2_20260811_095727.log`，test L2 **0.035012**；交卷复评见 `official_recheck_2026-08-14.log` 的 FNO REEVAL 段
- 未采纳内容及原因：未把未过线的探针权重当成正式成绩

## Agent 交互记录 4 · 数据

- 工具 / Agent：Cursor Agent（SSH）
- 场景标签：数据预处理与特征工程
- 目标：正式成绩只报官方公开 NS64
- 关键提示词或交互摘要：提交以公开集为准；须注明数据来源
- Agent 建议：loader 优先读官方 `.pt`；划分锁死 1000/128、种子 20260722
- 采纳的修改：接入 `navier_stokes_v1e-3_N1200_T20.pt`；正式权重 `fno_ns_public_demo.pt`
- 验证结果：官方数据上相对 L2 **0.035012**；见 `official_recheck_2026-08-14.log` 的 FNO REEVAL 段
- 未采纳内容及原因：未把非官方数据上的数字当成正式成绩

## Agent 交互记录 5 · 可视化

- 工具 / Agent：Cursor Agent（SSH）
- 场景标签：结果分析与可视化
- 目标：画出预测 / 真值 / 误差
- 关键提示词或交互摘要：要有给评委看的流场图
- Agent 建议：Pred/GT 共用色标，再加最好/中位/最差条带
- 采纳的修改：`进阶模型-FNO/visualize.py`；图在 `演示与展示/媒体/`
- 验证结果：`演示与展示/媒体/fno_ns_pred_vs_gt_2026-08-02.png`
- 未采纳内容及原因：未把非正式评测图当成官方数据展示

## Agent 交互记录 6 · BIREN 平台

- 工具 / Agent：Cursor Agent（SSH）
- 场景标签：BIREN GPU 平台适配
- 目标：在 Biren106B 单卡上可复现
- 关键提示词或交互摘要：先 source 环境；同一时间只跑一张卡
- Agent 建议：设备名 `supa`；`torch.cuda.is_available()` 为 False 正常
- 采纳的修改：交卷复测前先打 `brsmi`
- 验证结果：原始快照 `测试结果/运行日志/brsmi_snapshot.txt` 与 `official_recheck_2026-08-14.log` 开头的 BR-SMI 段
- 未采纳内容及原因：未与另一工作区并发占卡
