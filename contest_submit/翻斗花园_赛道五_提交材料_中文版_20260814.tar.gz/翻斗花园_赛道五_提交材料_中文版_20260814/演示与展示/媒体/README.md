# 媒体

现行展示只看本页列出的文件。图来自官方公开 NS64 + 正式权重，脚本是 `进阶模型-FNO/render_official_demo.py`（内部调用 `visualize.py`）。

| 文件 | 说明 |
|------|------|
| `fno_ns_pred_vs_gt_2026-08-14.png` | 预测 / 真值 / 误差 |
| `fno_ns_sample_strip_2026-08-14.png` | 最好 / 中位 / 最差条带 |
| `metrics_snapshot.md` | L2 **0.035012** + 算子三档耗时 |
| `brsmi_snapshot.txt` | 单卡运行快照 |
| `official_recheck_2026-08-14.log` | 交卷复测原始日志 |
