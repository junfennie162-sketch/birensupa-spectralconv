# 演示与展示

给评委看的流场图和运行快照。

图由 `进阶模型-FNO/render_official_demo.py` 生成：读取官方公开 NS64 和正式权重，在 1000/128 测试划分上前向，再交给 `visualize.py` 画预测 / 真值 / 误差。数字以 `results.md` 的相对 L2 **0.035012** 为准。

| 文件 | 说明 |
|------|------|
| `媒体/fno_ns_pred_vs_gt_2026-08-14.png` | 单样本：输入末帧、真值、预测、误差 |
| `媒体/fno_ns_sample_strip_2026-08-14.png` | 本批最好 / 中位 / 最差 |
| `媒体/brsmi_snapshot.txt` | 单卡运行快照 |
| `媒体/official_recheck_2026-08-14.log` | 08-14 复测原始 log |
| `媒体/metrics_snapshot.md` | 指标摘录 |
